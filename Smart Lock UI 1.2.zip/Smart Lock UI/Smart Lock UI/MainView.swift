// FILE: MainView.swift
import SwiftUI
import FirebaseAuth

struct MainView: View {
    @StateObject private var vm = LockViewModel()
    @State private var showAdminPanel = false

    var body: some View {
        VStack(spacing: 22) {
            Text("Smart Lock Control")
                .font(.title).bold()

            // Role indicator
            HStack(spacing: 8) {
                Circle()
                    .fill(vm.isAdmin ? Color.green : Color.blue)
                    .frame(width: 10, height: 10)
                Text("Account: \(vm.role.isEmpty ? "unknown" : vm.role)")
                    .font(.subheadline)
                    .foregroundColor(.gray)
            }

            Spacer(minLength: 12)

            // Buttons — ViewModelben: true = LOCKED
            LockButton(
                title: "Unlock A (1s)",
                isLocked: vm.lockA
            ) {
                vm.unlock(target: "A", durationMs: 1_000)
            }

            LockButton(
                title: "Unlock B (1s)",
                isLocked: vm.lockB
            ) {
                vm.unlock(target: "B", durationMs: 1_000)
            }

            LockButton(
                title: "Unlock BOTH (11s)",
                // NOW: green only when BOTH are unlocked (A and B both false)
                // isLocked = true in all other cases
                isLocked: (vm.lockA || vm.lockB)
            ) {
                vm.unlock(target: "BOTH", durationMs: 11_000)
            }

            Spacer()

            Text(vm.statusMessage)
                .font(.footnote)
                .foregroundColor(.gray)

            // Admin Panel button – only visible for admins
            if vm.isAdmin {
                Button {
                    showAdminPanel = true
                } label: {
                    HStack {
                        Image(systemName: "gearshape.fill")
                        Text("Admin Panel").bold()
                    }
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color(.secondarySystemBackground))
                    .cornerRadius(10)
                }
            }

            Button("Logout") {
                try? Auth.auth().signOut()
                exit(0)
            }
            .buttonStyle(.bordered)
        }
        .padding()
        .onAppear { vm.start() }
        // disable while loading or no permissions
        .disabled(!vm.canOperate || vm.isLoading)
        .sheet(isPresented: $showAdminPanel) {
            // embed in NavigationStack so title + toolbar appear
            NavigationStack {
                AdminPanelView(deviceId: vm.deviceId)
            }
        }
    }
}
