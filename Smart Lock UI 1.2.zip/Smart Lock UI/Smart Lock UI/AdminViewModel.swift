
import SwiftUI
import Combine
import FirebaseDatabase

struct UserRole: Identifiable {
    let id: String      // Firebase UID
    var nickname: String
    var canA: Bool
    var canB: Bool
    var isAdmin: Bool

    var displayName: String {
        nickname.isEmpty ? id : nickname
    }

    var canBoth: Bool {
        get { canA && canB }
        set {
            canA = newValue
            canB = newValue
        }
    }
}

struct RFIDEntry: Identifiable {
    let id: String      // Firebase key of the whitelist entry (e.g. "-OdzatHdWyXsazDZDUnd")
    var label: String   // This will hold the card UID from the "uid" field in the DB
    var canA: Bool
    var canB: Bool

    var canBoth: Bool {
        get { canA && canB }
        set {
            canA = newValue
            canB = newValue
        }
    }
}

class AdminViewModel: ObservableObject {
    @Published var userRoles: [UserRole] = []
    @Published var rfidEntries: [RFIDEntry] = []
    @Published var isLoading: Bool = false
    @Published var errorMessage: String?
    
    private let deviceId: String
    private let dbRef = Database.database().reference()
    
    init(deviceId: String) {
        self.deviceId = deviceId
    }
    
    // MARK: - Loading
    
    func load() {
        isLoading = true
        errorMessage = nil
        
        let group = DispatchGroup()
        
        group.enter()
        fetchRoles {
            group.leave()
        }
        
        group.enter()
        fetchRfidWhitelist {
            group.leave()
        }
        
        group.notify(queue: .main) {
            self.isLoading = false
        }
    }
    
    private func fetchRoles(completion: @escaping () -> Void) {
        dbRef.child("roles").observeSingleEvent(
            of: .value,
            with: { snapshot in
                var roles: [UserRole] = []
                
                if let root = snapshot.value as? [String: Any] {
                    for (uid, value) in root {
                        guard let devs = value as? [String: Any],
                              let devData = devs[self.deviceId] as? [String: Any] else {
                            continue
                        }
                        
                        let canA = devData["A"] as? Bool ?? false
                        let canB = devData["B"] as? Bool ?? false
                        let isAdmin = devData["admin"] as? Bool ?? false
                        let nickname = devData["nickname"] as? String ?? ""
                        
                        let role = UserRole(
                            id: uid,
                            nickname: nickname,
                            canA: canA,
                            canB: canB,
                            isAdmin: isAdmin
                        )
                        
                        roles.append(role)
                    }
                }
                
                DispatchQueue.main.async {
                    self.userRoles = roles.sorted { $0.displayName < $1.displayName }
                    completion()
                }
            },
            withCancel: { error in
                DispatchQueue.main.async {
                    self.errorMessage = "Roles load error: \(error.localizedDescription)"
                    completion()
                }
            }
        )
    }
    
    private func fetchRfidWhitelist(completion: @escaping () -> Void) {
        dbRef.child("rfidWhitelist").child(deviceId).observeSingleEvent(
            of: .value,
            with: { snapshot in
                var entries: [RFIDEntry] = []
                
                if let root = snapshot.value as? [String: Any] {
                    for (entryId, value) in root {
                        guard let fields = value as? [String: Any] else { continue }
                        
                        // UID comes from the "uid" field in the DB structure
                        let uidValue = fields["uid"] as? String ?? ""
                        
                        // Permission comes from "permission"; fall back to legacy A/B if needed
                        let permissionString: String
                        if let perm = fields["permission"] as? String {
                            permissionString = perm
                        } else {
                            let a = fields["A"] as? Bool ?? false
                            let b = fields["B"] as? Bool ?? false
                            permissionString = self.flagsToPermission(canA: a, canB: b)
                        }
                        
                        let (canA, canB) = self.permissionToFlags(permissionString)
                        
                        let entry = RFIDEntry(
                            id: entryId,
                            label: uidValue.isEmpty ? entryId : uidValue, // label used only for display
                            canA: canA,
                            canB: canB
                        )
                        
                        entries.append(entry)
                    }
                }
                
                DispatchQueue.main.async {
                    // Sort by UID (label) for nicer display
                    self.rfidEntries = entries.sorted { $0.label < $1.label }
                    completion()
                }
            },
            withCancel: { error in
                DispatchQueue.main.async {
                    self.errorMessage = "RFID load error: \(error.localizedDescription)"
                    completion()
                }
            }
        )
    }
    
    // MARK: - Local modifications (Roles)
    
    func updateRoleFlags(uid: String, canA: Bool? = nil, canB: Bool? = nil, isAdmin: Bool? = nil) {
        guard let index = userRoles.firstIndex(where: { $0.id == uid }) else { return }
        var role = userRoles[index]
        
        if let canA = canA { role.canA = canA }
        if let canB = canB { role.canB = canB }
        if let isAdmin = isAdmin { role.isAdmin = isAdmin }
        
        userRoles[index] = role
    }
    
    func updateRoleBoth(uid: String, enabled: Bool) {
        guard let index = userRoles.firstIndex(where: { $0.id == uid }) else { return }
        var role = userRoles[index]
        role.canBoth = enabled
        userRoles[index] = role
    }
    
    func deleteRole(uid: String) {
        userRoles.removeAll { $0.id == uid }
        dbRef.child("roles").child(uid).child(deviceId).removeValue()
    }
    
    // MARK: - Local modifications (RFID)
    
    func updateRfidLabel(cardId: String, label: String) {
        guard let index = rfidEntries.firstIndex(where: { $0.id == cardId }) else { return }
        var entry = rfidEntries[index]
        entry.label = label
        rfidEntries[index] = entry
    }
    
    func updateRfidFlags(cardId: String, canA: Bool? = nil, canB: Bool? = nil) {
        guard let index = rfidEntries.firstIndex(where: { $0.id == cardId }) else { return }
        var entry = rfidEntries[index]
        
        if let canA = canA { entry.canA = canA }
        if let canB = canB { entry.canB = canB }
        
        rfidEntries[index] = entry
    }
    
    func updateRfidBoth(cardId: String, enabled: Bool) {
        guard let index = rfidEntries.firstIndex(where: { $0.id == cardId }) else { return }
        var entry = rfidEntries[index]
        entry.canBoth = enabled
        rfidEntries[index] = entry
    }
    
    func deleteRfidEntry(cardId: String) {
        rfidEntries.removeAll { $0.id == cardId }
        dbRef.child("rfidWhitelist").child(deviceId).child(cardId).removeValue()
    }
    
    // MARK: - Save everything
    
    func saveAll() {
        // Save roles (unchanged except for nickname)
        for role in userRoles {
            let path = dbRef.child("roles").child(role.id).child(deviceId)
            let data: [String: Any] = [
                "A": role.canA,
                "B": role.canB,
                "admin": role.isAdmin,
                "nickname": role.nickname
            ]
            path.setValue(data)
        }
        
        // Save ONLY the "permission" field for each RFID entry.
        // Structure under each entryId remains:
        // { "permission": "...", "uid": "..." }
        for entry in rfidEntries {
            let permission = flagsToPermission(canA: entry.canA, canB: entry.canB)
            let permPath = dbRef
                .child("rfidWhitelist")
                .child(deviceId)
                .child(entry.id)
                .child("permission")
            
            permPath.setValue(permission)
        }
    }
    
    // MARK: - Permission mapping helpers
    
    private func permissionToFlags(_ perm: String) -> (Bool, Bool) {
        switch perm.uppercased() {
        case "A":
            return (true, false)
        case "B":
            return (false, true)
        case "BOTH":
            return (true, true)
        case "NOBODY":
            fallthrough
        default:
            return (false, false)
        }
    }
    
    private func flagsToPermission(canA: Bool, canB: Bool) -> String {
        switch (canA, canB) {
        case (true, true):
            return "BOTH"
        case (true, false):
            return "A"
        case (false, true):
            return "B"
        default:
            return "nobody"
        }
    }
}
