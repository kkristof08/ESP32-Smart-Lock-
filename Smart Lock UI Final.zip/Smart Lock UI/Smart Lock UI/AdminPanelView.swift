// FILE: AdminPanelView.swift
import SwiftUI

private enum AdminSection: String, CaseIterable, Identifiable {
    case roles = "Roles"
    case rfid = "RFID Whitelist"

    var id: String { rawValue }
}

private enum DeleteTarget {
    case role(String)
    case rfid(String)
}

private enum RfidPermission {
    case a, b, both, nobody
}

struct AdminPanelView: View {
    @StateObject private var vm: AdminViewModel
    @State private var selectedSection: AdminSection = .roles
    @State private var deleteTarget: DeleteTarget?

    init(deviceId: String) {
        _vm = StateObject(wrappedValue: AdminViewModel(deviceId: deviceId))
    }

    var body: some View {
        VStack {
            Picker("Section", selection: $selectedSection) {
                ForEach(AdminSection.allCases) { section in
                    Text(section.rawValue).tag(section)
                }
            }
            .pickerStyle(.segmented)
            .padding()

            if vm.isLoading {
                ProgressView("Loading…")
                    .padding()
            } else {
                switch selectedSection {
                case .roles:
                    rolesSection
                case .rfid:
                    rfidSection
                }
            }

            if let error = vm.errorMessage {
                Text(error)
                    .foregroundColor(.red)
                    .font(.footnote)
                    .padding()
            }
        }
        .navigationTitle("Admin Panel")
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                Button("Save") {
                    vm.saveAll()
                }
            }
        }
        .onAppear {
            vm.load()
        }
        .alert(
            "Confirm deletion",
            isPresented: Binding(
                get: { deleteTarget != nil },
                set: { if !$0 { deleteTarget = nil } }
            )
        ) {
            Button("Delete", role: .destructive) {
                if let target = deleteTarget {
                    switch target {
                    case .role(let uid):
                        vm.deleteRole(uid: uid)
                    case .rfid(let cardId):
                        vm.deleteRfidEntry(cardId: cardId)
                    }
                }
                deleteTarget = nil
            }
            Button("Cancel", role: .cancel) {
                deleteTarget = nil
            }
        } message: {
            Text("Are you sure you want to delete this entry? This action cannot be undone.")
        }
    }

    // MARK: - Roles UI

    private var rolesSection: some View {
        List {
            ForEach(vm.userRoles) { role in
                VStack(alignment: .leading, spacing: 8) {
                    HStack {
                        Text(role.displayName)
                            .font(.headline)
                        Spacer()
                        Button(role.isAdmin ? "Admin" : "User") {
                            vm.updateRoleFlags(uid: role.id, isAdmin: !role.isAdmin)
                        }
                        .font(.caption)
                        .padding(6)
                        .background(role.isAdmin ? Color.green.opacity(0.2) :
                                     Color.gray.opacity(0.2))
                        .cornerRadius(8)
                    }

                    HStack {
                        Toggle("A", isOn: Binding(
                            get: { role.canA },
                            set: { newValue in
                                vm.updateRoleFlags(uid: role.id, canA: newValue)
                            })
                        )

                        Toggle("B", isOn: Binding(
                            get: { role.canB },
                            set: { newValue in
                                vm.updateRoleFlags(uid: role.id, canB: newValue)
                            })
                        )

                        Toggle("BOTH", isOn: Binding(
                            get: { role.canBoth },
                            set: { newValue in
                                vm.updateRoleBoth(uid: role.id, enabled: newValue)
                            })
                        )
                    }

                    HStack {
                        Spacer()
                        Button("Delete account") {
                            deleteTarget = .role(role.id)
                        }
                        .foregroundColor(.red)
                        .font(.caption)
                    }
                }
                .padding(.vertical, 4)
                // 🔹 ITT A LÉNYEG:
                // Admin account sorai legyenek szürkék és nem módosíthatók
                .disabled(role.isAdmin)
                .opacity(role.isAdmin ? 0.5 : 1.0)
            }
        }
    }

    // MARK: - RFID UI

    private var rfidSection: some View {
        List {
            ForEach(vm.rfidEntries) { entry in
                let perm = currentPermission(for: entry)

                VStack(alignment: .leading, spacing: 8) {
                    HStack {
                        // entry.id = entry-id, entry.label = UID (DB 'uid' field)
                        Text("UID:\(entry.label)")
                            .font(.subheadline)
                            .lineLimit(1)
                        Spacer()
                    }

                    HStack {
                        permissionButton(
                            title: "A",
                            isSelected: perm == .a
                        ) {
                            vm.updateRfidFlags(cardId: entry.id, canA: true, canB: false)
                        }

                        permissionButton(
                            title: "B",
                            isSelected: perm == .b
                        ) {
                            vm.updateRfidFlags(cardId: entry.id, canA: false, canB: true)
                        }

                        permissionButton(
                            title: "BOTH",
                            isSelected: perm == .both
                        ) {
                            vm.updateRfidBoth(cardId: entry.id, enabled: true)
                        }

                        permissionButton(
                            title: "nobody",
                            isSelected: perm == .nobody
                        ) {
                            vm.updateRfidFlags(cardId: entry.id, canA: false, canB: false)
                        }
                    }

                    HStack {
                        Spacer()
                        Button("Delete card") {
                            deleteTarget = .rfid(entry.id)
                        }
                        .foregroundColor(.red)
                        .font(.caption)
                    }
                }
                .padding(.vertical, 4)
            }
        }
    }

    // MARK: - Helpers (RFID permissions)

    private func currentPermission(for entry: RFIDEntry) -> RfidPermission {
        if entry.canA && entry.canB {
            return .both
        } else if entry.canA {
            return .a
        } else if entry.canB {
            return .b
        } else {
            return .nobody
        }
    }

    private func permissionButton(
        title: String,
        isSelected: Bool,
        action: @escaping () -> Void
    ) -> some View {
        Button(action: action) {
            Text(title)
                .font(.caption)
                .padding(6)
                .frame(maxWidth: .infinity)
                .background(isSelected ? Color.blue.opacity(0.2) : Color.gray.opacity(0.1))
                .cornerRadius(8)
        }
        .buttonStyle(.plain)
    }
}
