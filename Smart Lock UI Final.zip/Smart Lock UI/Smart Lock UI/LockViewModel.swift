import Foundation
import Combine
import SwiftUI
import FirebaseAuth
import FirebaseDatabase

@MainActor
final class LockViewModel: ObservableObject {
    
    // MARK: - Published UI state
    // These booleans represent **LOCKED** state in the UI (true = locked)
    @Published var role: String = ""
    @Published var lockA: Bool = false    // UI: true = locked
    @Published var lockB: Bool = false
    @Published var statusMessage: String = "Locked"
    @Published var isLoading: Bool = true

    // 🔢 ÚJ: visszaszámláló értékek A és B számára
    @Published var timerA: Int = 0
    @Published var timerB: Int = 0
    
    // MARK: - Config
    let deviceId: String = "esp32-01"
    
    // MARK: - Firebase
    private let dbRef = Database.database().reference()
    
    // MARK: - Derived permissions
    var isAdmin: Bool { role == "admin" }
    var canOperate: Bool { role == "admin" || role == "operator" }

    // 🔁 ÚJ: Task-ok a visszaszámlálókhoz (hogy lehessen őket törölni / újraindítani)
    private var countdownTaskA: Task<Void, Never>?
    private var countdownTaskB: Task<Void, Never>?
    
    // MARK: - Lifecycle
    func start() {
        guard let uid = Auth.auth().currentUser?.uid else {
            statusMessage = "Not logged in"
            isLoading = false
            return
        }
        
        // Load role from roles/{uid}/{deviceId} = { "A": Bool, "B": Bool, "admin": Bool }
        dbRef.child("roles").child(uid).child(deviceId)
            .observeSingleEvent(of: .value) { [weak self] snap in
                Task { @MainActor in
                    guard let self = self else { return }
                    
                    if let dict = snap.value as? [String: Any] {
                        let a = dict["A"] as? Bool ?? false
                        let b = dict["B"] as? Bool ?? false
                        let admin = dict["admin"] as? Bool ?? false
                        
                        if admin {
                            self.role = "admin"
                        } else if a || b {
                            self.role = "operator"
                        } else {
                            self.role = "nobody"
                        }
                    } else {
                        self.role = "nobody"
                    }
                }
            }
        
        // Live device state
        let statePath = "devices/\(deviceId)/state"
        dbRef.child(statePath).observe(.value) { [weak self] snap in
            guard let self = self else { return }
            
            guard let dict = snap.value as? [String: Any] else {
                Task { @MainActor in
                    self.lockA = true
                    self.lockB = true
                    self.statusMessage = "Locked"
                    self.isLoading = false
                }
                return
            }
            
            // Firmware semantics: in DB, true = UNLOCKED (energized)
            let aRaw = dict["lockA"] as? Bool ?? false
            let bRaw = dict["lockB"] as? Bool ?? false
            
            // Convert to UI semantics (true = locked)
            let aLocked = !aRaw
            let bLocked = !bRaw
            
            Task { @MainActor in
                self.lockA = aLocked
                self.lockB = bLocked
                let overallLocked = aLocked && bLocked
                self.statusMessage = overallLocked ? "Locked" : "Unlocked"
                self.isLoading = false
            }
        }
    }
    
    // MARK: - Commands

    /// UNLOCK parancs küldése + visszaszámlálók indítása
    func unlock(target: String, durationMs: Int = 1_000) {
        // 🔢 Visszaszámlálás logika
        switch target {
        case "A":
            startCountdown(for: .a)
        case "B":
            startCountdown(for: .b)
        case "BOTH":
            // A azonnal indul
            startCountdown(for: .a)
            // B 300 ms késleltetéssel indul
            startCountdownForBWithDelay()
        default:
            break
        }

        // Eredeti funkció: parancs küldése az ESP32-nek
        sendCommand(target: target, action: "UNLOCK", durationMs: durationMs)
    }
    
    func lock(target: String) {
        sendCommand(target: target, action: "LOCK", durationMs: 200)
    }
    
    private func sendCommand(target: String, action: String, durationMs: Int?) {
        guard canOperate else {
            statusMessage = "Insufficient privileges"
            return
        }
        guard let uid = Auth.auth().currentUser?.uid else {
            statusMessage = "Not logged in"
            return
        }
        
        // Compute pulseMs exactly as rules expect
        let pulseMs: Int
        if target == "BOTH" {
            // BOTH branch in rules: pulseMs must be exactly 11000
            pulseMs = 11_000
        } else {
            // A/B branch: 100–1200 allowed
            let raw = durationMs ?? 1_000
            pulseMs = max(100, min(raw, 1_200))
        }
        
        let cmdRef = dbRef.child("commands").child(deviceId).child("lastCmd")
        
        var payload: [String: Any] = [
            "target": target,         // "A" | "B" | "BOTH"
            "action": action,         // "UNLOCK" | "LOCK"
            "pulseMs": pulseMs,
            "issuedBy": uid,
            "done": false
        ]
        
        payload["id"] = UUID().uuidString
        
        cmdRef.setValue(payload) { [weak self] error, _ in
            if let error = error {
                Task { @MainActor in
                    self?.statusMessage = "Error: \(error.localizedDescription)"
                }
                return
            }
            Task { @MainActor in
                self?.statusMessage = "\(action.capitalized) \(target) sent"
            }
            
            cmdRef.child("done").observe(.value) { [weak self] snap in
                if let done = snap.value as? Bool, done {
                    Task { @MainActor in
                        self?.statusMessage = "ESP32 confirmed \(action.lowercased())"
                    }
                    cmdRef.child("done").removeAllObservers()
                }
            }
        }
    }

    // MARK: - Visszaszámláló logika (ÚJ)

    private enum LockSide {
        case a, b
    }

    /// 10-től 0-ig számol vissza az adott zárhoz, 1 másodpercenként.
    private func startCountdown(for side: LockSide) {
        // Előző Task megszakítása, ha volt
        switch side {
        case .a:
            countdownTaskA?.cancel()
        case .b:
            countdownTaskB?.cancel()
        }

        let task = Task { [weak self] in
            for value in stride(from: 10, through: 0, by: -1) {
                // Ha a Task-ot törölték, lépjünk ki
                if Task.isCancelled { break }

                await MainActor.run {
                    switch side {
                    case .a:
                        self?.timerA = value
                    case .b:
                        self?.timerB = value
                    }
                }

                // 1 másodperces lépések
                try? await Task.sleep(nanoseconds: 1_000_000_000)
            }
        }

        switch side {
        case .a:
            countdownTaskA = task
        case .b:
            countdownTaskB = task
        }
    }
    /// B visszaszámláló indítása 300 ms késleltetéssel (BOTH esetén)
    private func startCountdownForBWithDelay() {
        countdownTaskB?.cancel()
        countdownTaskB = Task { [weak self] in
            // 300 ms késleltetés
            try? await Task.sleep(nanoseconds: 300_000_000)
            await self?.startCountdown(for: .b)
        }
    }
}

