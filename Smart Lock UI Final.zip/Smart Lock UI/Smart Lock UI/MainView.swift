
// FILE: MainView.swift
import SwiftUI
import FirebaseAuth

struct MainView: View {
    @Binding var isLoggedIn: Bool          // <- ÚJ: kívülről kapjuk, hogy vissza tudjunk lépni LoginView-ra
    @StateObject private var vm = LockViewModel()
    @State private var showAdminPanel = false

    var body: some View {
        VStack(spacing: 22) {
            Text("Smart Lock Control")
                .font(.title).bold()

            // Role indicator
            HStack(spacing: 8) {
                Circle()
                    .fill(vm.isAdmin ? Color.green : Color.blue)
                    .frame(width: 10, height: 10)
                Text("Account: \(vm.role.isEmpty ? "unknown" : vm.role)")
                    .font(.subheadline)
                    .foregroundColor(.gray)
            }

            Spacer(minLength: 12)

            // 🔒 Minden, ami a zár vezérléséhez kell + admin panel
            Group {
                // Buttons — ViewModelben: true = LOCKED
                LockButton(
                    title: vm.timerA > 0
                        ? "Unlock A (\(vm.timerA)s)"
                        : "Unlock A",
                    isLocked: vm.lockA
                ) {
                    vm.unlock(target: "A", durationMs: 1_000)
                }

                // B gomb
                LockButton(
                    title: vm.timerB > 0
                        ? "Unlock B (\(vm.timerB)s)"
                        : "Unlock B",
                    isLocked: vm.lockB
                ) {
                    vm.unlock(target: "B", durationMs: 1_000)
                }

                // BOTH gomb – pl. az A timerét mutatjuk (mert az indul el először)
                LockButton(
                    title: vm.timerA > 0
                        ? "Unlock BOTH (\(vm.timerA)s)"
                        : "Unlock BOTH",
                    // NOW: green only when BOTH are unlocked (A and B both false)
                    // isLocked = true in all other cases
                    isLocked: (vm.lockA || vm.lockB)
                ) {
                    vm.unlock(target: "BOTH", durationMs: 11_000)
                }
                Spacer()

                Text(vm.statusMessage)
                    .font(.footnote)
                    .foregroundColor(.gray)

                // Admin Panel button – only visible for admins
                if vm.isAdmin {
                    Button {
                        showAdminPanel = true
                    } label: {
                        HStack {
                            Image(systemName: "gearshape.fill")
                            Text("Admin Panel").bold()
                        }
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color(.secondarySystemBackground))
                        .cornerRadius(10)
                    }
                }
            }
            // ⚠️ CSAK a vezérlőrészt tiltjuk, a Logout gombot NEM
            .disabled(!vm.canOperate || vm.isLoading)

            // 🔁 Logout – mindig látható és használható
            Button("Logout") {
                try? Auth.auth().signOut()
                isLoggedIn = false      // <- Ezzel vissza fogsz esni a LoginView-ra
            }
            .buttonStyle(.bordered)
        }
        .padding()
        .onAppear { vm.start() }
        .sheet(isPresented: $showAdminPanel) {
            // embed in NavigationStack so title + toolbar appear
            NavigationStack {
                AdminPanelView(deviceId: vm.deviceId)
            }
        }
    }
}
