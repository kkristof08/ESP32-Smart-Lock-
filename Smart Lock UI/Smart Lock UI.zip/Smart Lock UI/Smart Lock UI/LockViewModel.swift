// FILE: LockViewModel.swift
import Foundation
import Combine
import SwiftUI
import FirebaseAuth
import FirebaseDatabase

@MainActor
final class LockViewModel: ObservableObject {

    // MARK: - Published UI state
    // These booleans represent **LOCKED** state in the UI (true = locked)
    @Published var role: String = ""
    @Published var lockA: Bool = false    // default to LOCKED for initial UI
    @Published var lockB: Bool = false   // default to LOCKED for initial UI
    @Published var statusMessage: String = "Locked"
    @Published var isLoading: Bool = true

    // MARK: - Config
    let deviceId: String = "esp32-01"

    // MARK: - Firebase
    private let dbRef = Database.database().reference()

    // MARK: - Derived permissions
    var isAdmin: Bool { role == "admin" }
    var canOperate: Bool { role == "admin" || role == "operator" }

    // MARK: - Lifecycle
    func start() {
        guard let uid = Auth.auth().currentUser?.uid else {
            statusMessage = "Not logged in"
            isLoading = false
            return
        }

        // Load role once
        dbRef.child("roles/\(uid)/\(deviceId)")
            .observeSingleEvent(of: .value) { [weak self] snap in
                Task { @MainActor in
                    self?.role = (snap.value as? String) ?? "operator"
                }
            }

        // Live device state (Firmware semantics: true = UNLOCKED / energized)
        let statePath = "devices/\(deviceId)/state"
        dbRef.child(statePath).observe(.value) { [weak self] snap in
            guard let self = self else { return }

            // If no data yet, assume both locked for safer default
            guard let dict = snap.value as? [String: Any] else {
                Task { @MainActor in
                    self.lockA = true
                    self.lockB = true
                    self.statusMessage = "Locked"
                    self.isLoading = false
                }
                return
            }

            let aRaw = dict["lockA"] as? Bool ?? false   // true = unlocked (energized)
            let bRaw = dict["lockB"] as? Bool ?? false   // true = unlocked (energized)

            // Convert to UI semantics (true = locked)
            let aLocked = !aRaw
            let bLocked = !bRaw

            Task { @MainActor in
                self.lockA = aLocked
                self.lockB = bLocked
                let overallLocked = aLocked && bLocked
                self.statusMessage = overallLocked ? "Locked" : "Unlocked"
                self.isLoading = false
            }
        }
    }

    // MARK: - Commands
    // Firmware expects: { target: "A"|"B"|"BOTH", action: "UNLOCK"|"LOCK", durationMs: Int, done: false }
    func unlock(target: String, durationMs: Int = 10_000) {
        sendCommand(target: target, action: "UNLOCK", durationMs: durationMs)
    }

    func lock(target: String) {
        // duration not required for LOCK; ignored by firmware if present
        sendCommand(target: target, action: "LOCK", durationMs: nil)
    }

    private func sendCommand(target: String, action: String, durationMs: Int?) {
        guard canOperate else {
            statusMessage = "Insufficient privileges"
            return
        }
        guard let uid = Auth.auth().currentUser?.uid else {
            statusMessage = "Not logged in"
            return
        }

        let cmdRef = dbRef.child("commands").child(deviceId).child("lastCmd")
        var payload: [String: Any] = [
            "id": UUID().uuidString,
            "target": target,         // "A" | "B" | "BOTH"
            "action": action,         // "UNLOCK" | "LOCK"
            "issuedBy": uid,
            "done": false
        ]
        if let durationMs = durationMs {
            payload["durationMs"] = durationMs
        }

        cmdRef.setValue(payload) { [weak self] error, _ in
            if let error = error {
                Task { @MainActor in
                    self?.statusMessage = "Error: \(error.localizedDescription)"
                }
                return
            }
            Task { @MainActor in
                self?.statusMessage = "\(action.capitalized) \(target) sent"
            }

            // Observe ack
            cmdRef.child("done").observe(.value) { [weak self] snap in
                if let done = snap.value as? Bool, done {
                    Task { @MainActor in
                        self?.statusMessage = "ESP32 confirmed \(action.lowercased())"
                    }
                    cmdRef.child("done").removeAllObservers()
                }
            }
        }
    }
}
