import SwiftUI
import FirebaseAuth

struct MainView: View {
    @StateObject private var vm = LockViewModel()

    var body: some View {
        VStack(spacing: 22) {
            Text("Smart Lock Control")
                .font(.title).bold()

            // Role indicator
            HStack(spacing: 8) {
                Circle()
                    .fill(vm.isAdmin ? Color.green : Color.blue)
                    .frame(width: 10, height: 10)
                Text("Account: \(vm.role.isEmpty ? "unknown" : vm.role)")
                    .font(.subheadline)
                    .foregroundColor(.gray)
            }

            Spacer(minLength: 12)

            // Buttons — ViewModelben: true = LOCKED
            LockButton(
                title: "Unlock A (10s)",
                isLocked: vm.lockA
            ) {
                vm.unlock(target: "A", durationMs: 10_000)
            }

            LockButton(
                title: "Unlock B (10s)",
                isLocked: vm.lockB
            ) {
                vm.unlock(target: "B", durationMs: 10_000)
            }

            LockButton(
                title: "Unlock BOTH (10s)",
                isLocked: (vm.lockA && vm.lockB)   // csak akkor „Locked”, ha mindkettő zárva
            ) {
                vm.unlock(target: "BOTH", durationMs: 10_000)
            }

            Spacer()

            Text(vm.statusMessage)
                .font(.footnote)
                .foregroundColor(.gray)

            Button("Logout") {
                try? Auth.auth().signOut()
                exit(0)
            }
            .buttonStyle(.bordered)
        }
        .padding()
        .onAppear { vm.start() }
        .disabled(!vm.canOperate || vm.isLoading) // opcionális: tiltja a gombokat jogosultság/terhelés esetén
    }
}
