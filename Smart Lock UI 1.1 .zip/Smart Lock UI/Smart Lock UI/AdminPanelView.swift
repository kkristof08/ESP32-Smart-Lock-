// FILE: AdminPanelView.swift
import SwiftUI

private enum AdminSection: String, CaseIterable, Identifiable {
    case roles = "Roles"
    case rfid = "RFID Whitelist"

    var id: String { rawValue }
}

struct AdminPanelView: View {
    @StateObject private var vm: AdminViewModel
    @State private var selectedSection: AdminSection = .roles

    init(deviceId: String) {
        _vm = StateObject(wrappedValue: AdminViewModel(deviceId: deviceId))
    }

    var body: some View {
        VStack {
            Picker("Section", selection: $selectedSection) {
                ForEach(AdminSection.allCases) { section in
                    Text(section.rawValue).tag(section)
                }
            }
            .pickerStyle(.segmented)
            .padding()

            if vm.isLoading {
                ProgressView("Loading…")
                    .padding()
            } else {
                switch selectedSection {
                case .roles:
                    rolesSection
                case .rfid:
                    rfidSection
                }
            }

            if let error = vm.errorMessage {
                Text(error)
                    .foregroundColor(.red)
                    .font(.footnote)
                    .padding()
            }
        }
        .navigationTitle("Admin Panel")
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                Button("Save") {
                    vm.saveAll()
                }
            }
        }
        .onAppear {
            vm.load()
        }
    }

    private var rolesSection: some View {
        List {
            ForEach(vm.userRoles) { role in
                VStack(alignment: .leading, spacing: 8) {
                    HStack {
                        Text(role.displayName)
                            .font(.headline)
                        Spacer()
                        Button(role.isAdmin ? "Admin" : "User") {
                            vm.updateRoleFlags(uid: role.id, isAdmin: !role.isAdmin)
                        }
                        .font(.caption)
                        .padding(6)
                        .background(role.isAdmin ? Color.green.opacity(0.2) :
                                     Color.gray.opacity(0.2))
                        .cornerRadius(8)
                    }

                    HStack {
                        Toggle("A", isOn: Binding(
                            get: { role.canA },
                            set: { newValue in
                                vm.updateRoleFlags(uid: role.id, canA: newValue)
                            })
                        )

                        Toggle("B", isOn: Binding(
                            get: { role.canB },
                            set: { newValue in
                                vm.updateRoleFlags(uid: role.id, canB: newValue)
                            })
                        )

                        Toggle("BOTH", isOn: Binding(
                            get: { role.canBoth },
                            set: { newValue in
                                vm.updateRoleBoth(uid: role.id, enabled: newValue)
                            })
                        )
                    }

                    HStack {
                        Spacer()
                        Button("Delete account") {
                            vm.deleteRole(uid: role.id)
                        }
                        .foregroundColor(.red)
                        .font(.caption)
                    }
                }
                .padding(.vertical, 4)
            }
        }
    }

    private var rfidSection: some View {
        List {
            ForEach(vm.rfidEntries) { entry in
                VStack(alignment: .leading, spacing: 8) {
                    HStack {
                        TextField("Label", text: Binding(
                            get: { entry.label },
                            set: { newValue in
                                vm.updateRfidLabel(cardId: entry.id, label: newValue)
                            })
                        )
                        .textFieldStyle(.roundedBorder)

                        Spacer()

                        Text(entry.id)
                            .font(.caption2)
                            .foregroundColor(.gray)
                            .lineLimit(1)
                    }

                    HStack {
                        Toggle("A", isOn: Binding(
                            get: { entry.canA },
                            set: { newValue in
                                vm.updateRfidFlags(cardId: entry.id, canA: newValue)
                            })
                        )

                        Toggle("B", isOn: Binding(
                            get: { entry.canB },
                            set: { newValue in
                                vm.updateRfidFlags(cardId: entry.id, canB: newValue)
                            })
                        )

                        Toggle("BOTH", isOn: Binding(
                            get: { entry.canBoth },
                            set: { newValue in
                                vm.updateRfidBoth(cardId: entry.id, enabled: newValue)
                            })
                        )
                    }

                    HStack {
                        Spacer()
                        Button("Delete card") {
                            vm.deleteRfidEntry(cardId: entry.id)
                        }
                        .foregroundColor(.red)
                        .font(.caption)
                    }
                }
                .padding(.vertical, 4)
            }
        }
    }
}
