// FILE: AdminViewModel.swift
import SwiftUI
import Combine
import FirebaseDatabase

struct UserRole: Identifiable {
    let id: String      // Firebase UID
    var displayName: String
    var canA: Bool
    var canB: Bool
    var isAdmin: Bool

    var canBoth: Bool {
        get { canA && canB }
        set {
            canA = newValue
            canB = newValue
        }
    }
}

struct RFIDEntry: Identifiable {
    let id: String      // card UID
    var label: String
    var canA: Bool
    var canB: Bool

    var canBoth: Bool {
        get { canA && canB }
        set {
            canA = newValue
            canB = newValue
        }
    }
}

class AdminViewModel: ObservableObject {
    @Published var userRoles: [UserRole] = []
    @Published var rfidEntries: [RFIDEntry] = []
    @Published var isLoading: Bool = false
    @Published var errorMessage: String?

    private let deviceId: String
    private let dbRef = Database.database().reference()

    init(deviceId: String) {
        self.deviceId = deviceId
    }

    // MARK: - Loading

    func load() {
        isLoading = true
        errorMessage = nil

        let group = DispatchGroup()

        group.enter()
        fetchRoles {
            group.leave()
        }

        group.enter()
        fetchRfidWhitelist {
            group.leave()
        }

        group.notify(queue: .main) {
            self.isLoading = false
        }
    }

    private func fetchRoles(completion: @escaping () -> Void) {
        dbRef.child("roles").observeSingleEvent(
            of: .value,
            with: { snapshot in
                var roles: [UserRole] = []

                if let root = snapshot.value as? [String: Any] {
                    for (uid, value) in root {
                        guard let devs = value as? [String: Any],
                              let devData = devs[self.deviceId] as? [String: Any] else {
                            continue
                        }

                        let canA = devData["A"] as? Bool ?? false
                        let canB = devData["B"] as? Bool ?? false
                        let isAdmin = devData["admin"] as? Bool ?? false

                        let role = UserRole(
                            id: uid,
                            displayName: uid,
                            canA: canA,
                            canB: canB,
                            isAdmin: isAdmin
                        )

                        roles.append(role)
                    }
                }

                DispatchQueue.main.async {
                    self.userRoles = roles.sorted { $0.displayName < $1.displayName }
                    completion()
                }
            },
            withCancel: { error in
                DispatchQueue.main.async {
                    self.errorMessage = "Roles load error: \(error.localizedDescription)"
                    completion()
                }
            }
        )
    }

    private func fetchRfidWhitelist(completion: @escaping () -> Void) {
        dbRef.child("rfidWhitelist").child(deviceId).observeSingleEvent(
            of: .value,
            with: { snapshot in
                var entries: [RFIDEntry] = []

                if let root = snapshot.value as? [String: Any] {
                    for (cardId, value) in root {
                        guard let fields = value as? [String: Any] else { continue }

                        let label = fields["label"] as? String ?? cardId
                        let canA = fields["A"] as? Bool ?? false
                        let canB = fields["B"] as? Bool ?? false

                        let entry = RFIDEntry(
                            id: cardId,
                            label: label,
                            canA: canA,
                            canB: canB
                        )

                        entries.append(entry)
                    }
                }

                DispatchQueue.main.async {
                    self.rfidEntries = entries.sorted { $0.label < $1.label }
                    completion()
                }
            },
            withCancel: { error in
                DispatchQueue.main.async {
                    self.errorMessage = "RFID load error: \(error.localizedDescription)"
                    completion()
                }
            }
        )
    }

    // MARK: - Local modifications (Roles)

    func updateRoleFlags(uid: String, canA: Bool? = nil, canB: Bool? = nil, isAdmin: Bool? = nil) {
        guard let index = userRoles.firstIndex(where: { $0.id == uid }) else { return }
        var role = userRoles[index]

        if let canA = canA { role.canA = canA }
        if let canB = canB { role.canB = canB }
        if let isAdmin = isAdmin { role.isAdmin = isAdmin }

        userRoles[index] = role
    }

    func updateRoleBoth(uid: String, enabled: Bool) {
        guard let index = userRoles.firstIndex(where: { $0.id == uid }) else { return }
        var role = userRoles[index]
        role.canBoth = enabled
        userRoles[index] = role
    }

    func deleteRole(uid: String) {
        userRoles.removeAll { $0.id == uid }
        dbRef.child("roles").child(uid).child(deviceId).removeValue()
    }

    // MARK: - Local modifications (RFID)

    func updateRfidLabel(cardId: String, label: String) {
        guard let index = rfidEntries.firstIndex(where: { $0.id == cardId }) else { return }
        var entry = rfidEntries[index]
        entry.label = label
        rfidEntries[index] = entry
    }

    func updateRfidFlags(cardId: String, canA: Bool? = nil, canB: Bool? = nil) {
        guard let index = rfidEntries.firstIndex(where: { $0.id == cardId }) else { return }
        var entry = rfidEntries[index]

        if let canA = canA { entry.canA = canA }
        if let canB = canB { entry.canB = canB }

        rfidEntries[index] = entry
    }

    func updateRfidBoth(cardId: String, enabled: Bool) {
        guard let index = rfidEntries.firstIndex(where: { $0.id == cardId }) else { return }
        var entry = rfidEntries[index]
        entry.canBoth = enabled
        rfidEntries[index] = entry
    }

    func deleteRfidEntry(cardId: String) {
        rfidEntries.removeAll { $0.id == cardId }
        dbRef.child("rfidWhitelist").child(deviceId).child(cardId).removeValue()
    }

    // MARK: - Save everything

    func saveAll() {
        for role in userRoles {
            let path = dbRef.child("roles").child(role.id).child(deviceId)
            let data: [String: Any] = [
                "A": role.canA,
                "B": role.canB,
                "admin": role.isAdmin
            ]
            path.setValue(data)
        }

        let wlPath = dbRef.child("rfidWhitelist").child(deviceId)
        var wlData: [String: Any] = [:]

        for entry in rfidEntries {
            wlData[entry.id] = [
                "label": entry.label,
                "A": entry.canA,
                "B": entry.canB
            ]
        }

        wlPath.setValue(wlData)
    }
}
