import Foundation
import Combine
import SwiftUI
import FirebaseAuth
import FirebaseDatabase

@MainActor
final class LockViewModel: ObservableObject {
    
    // MARK: - Published UI state
    // These booleans represent **LOCKED** state in the UI (true = locked)
    @Published var role: String = ""
    @Published var lockA: Bool = false    // UI: true = locked
    @Published var lockB: Bool = false
    @Published var statusMessage: String = "Locked"
    @Published var isLoading: Bool = true
    
    // MARK: - Config
    let deviceId: String = "esp32-01"
    
    // MARK: - Firebase
    private let dbRef = Database.database().reference()
    
    // MARK: - Derived permissions
    var isAdmin: Bool { role == "admin" }
    var canOperate: Bool { role == "admin" || role == "operator" }
    
    // MARK: - Lifecycle
    func start() {
        guard let uid = Auth.auth().currentUser?.uid else {
            statusMessage = "Not logged in"
            isLoading = false
            return
        }
        
        // Load role from roles/{uid}/{deviceId} = { "A": Bool, "B": Bool, "admin": Bool }
        dbRef.child("roles").child(uid).child(deviceId)
            .observeSingleEvent(of: .value) { [weak self] snap in
                Task { @MainActor in
                    guard let self = self else { return }
                    
                    if let dict = snap.value as? [String: Any] {
                        let a = dict["A"] as? Bool ?? false
                        let b = dict["B"] as? Bool ?? false
                        let admin = dict["admin"] as? Bool ?? false
                        
                        if admin {
                            self.role = "admin"
                        } else if a || b {
                            self.role = "operator"
                        } else {
                            self.role = "nobody"
                        }
                    } else {
                        self.role = "nobody"
                    }
                }
            }
        
        // Live device state
        let statePath = "devices/\(deviceId)/state"
        dbRef.child(statePath).observe(.value) { [weak self] snap in
            guard let self = self else { return }
            
            guard let dict = snap.value as? [String: Any] else {
                Task { @MainActor in
                    self.lockA = true
                    self.lockB = true
                    self.statusMessage = "Locked"
                    self.isLoading = false
                }
                return
            }
            
            // Firmware semantics: in DB, true = UNLOCKED (energized)
            let aRaw = dict["lockA"] as? Bool ?? false
            let bRaw = dict["lockB"] as? Bool ?? false
            
            // Convert to UI semantics (true = locked)
            let aLocked = !aRaw
            let bLocked = !bRaw
            
            Task { @MainActor in
                self.lockA = aLocked
                self.lockB = bLocked
                let overallLocked = aLocked && bLocked
                self.statusMessage = overallLocked ? "Locked" : "Unlocked"
                self.isLoading = false
            }
        }
    }
    
    // MARK: - Commands
    func unlock(target: String, durationMs: Int = 1_000) {
        sendCommand(target: target, action: "UNLOCK", durationMs: durationMs)
    }
    
    func lock(target: String) {
        sendCommand(target: target, action: "LOCK", durationMs: 200)
    }
    
    private func sendCommand(target: String, action: String, durationMs: Int?) {
        guard canOperate else {
            statusMessage = "Insufficient privileges"
            return
        }
        guard let uid = Auth.auth().currentUser?.uid else {
            statusMessage = "Not logged in"
            return
        }
        
        // Compute pulseMs exactly as rules expect
        let pulseMs: Int
        if target == "BOTH" {
            // BOTH branch in rules: pulseMs must be exactly 11000
            pulseMs = 11_000
        } else {
            // A/B branch: 100–1200 allowed
            let raw = durationMs ?? 1_000
            pulseMs = max(100, min(raw, 1_200))
        }
        
        let cmdRef = dbRef.child("commands").child(deviceId).child("lastCmd")
        
        var payload: [String: Any] = [
            "target": target,         // "A" | "B" | "BOTH"
            "action": action,         // "UNLOCK" | "LOCK"
            "pulseMs": pulseMs,
            "issuedBy": uid,
            "done": false
        ]
        
        payload["id"] = UUID().uuidString
        
        cmdRef.setValue(payload) { [weak self] error, _ in
            if let error = error {
                Task { @MainActor in
                    self?.statusMessage = "Error: \(error.localizedDescription)"
                }
                return
            }
            Task { @MainActor in
                self?.statusMessage = "\(action.capitalized) \(target) sent"
            }
            
            cmdRef.child("done").observe(.value) { [weak self] snap in
                if let done = snap.value as? Bool, done {
                    Task { @MainActor in
                        self?.statusMessage = "ESP32 confirmed \(action.lowercased())"
                    }
                    cmdRef.child("done").removeAllObservers()
                }
            }
        }
    }
}

